const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
}

let state = JSON.parse(localStorage.getItem("reward_miniapp_demo") || "null") || {
  coins: 294.51, cycles: 5
};

function save(){localStorage.setItem("reward_miniapp_demo",JSON.stringify(state));}
function render(){
  document.getElementById("coins").textContent = state.coins.toFixed(2);
  document.getElementById("coinTop").textContent = state.coins.toFixed(2);
  document.getElementById("cycleCount").textContent = state.cycles;
  document.getElementById("progress").style.width = (state.cycles/14*100)+"%";
}
function addCoins(){
  state.coins += 10;
  state.cycles = Math.min(14,state.cycles+1);
  save(); render();
  showMessage("+10 demo coins added");
}
function showMessage(text){
  const t=document.getElementById("toast");
  t.textContent=text;t.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(()=>t.classList.remove("show"),2200);
}
function setTab(el){
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));
  el.classList.add("active");
  showMessage(el.innerText.replace(/\n/g," ")+" section is a demo");
}
if(tg?.initDataUnsafe?.user){
  const u=tg.initDataUnsafe.user;
  const display=u.first_name || "Telegram User";
  document.getElementById("name").textContent=display;
  const initials=(u.first_name?.[0]||"T")+(u.last_name?.[0]||"");
  document.getElementById("avatar").textContent=initials.toUpperCase();
}
render();
